#!/usr/bin/env bash

# DESCRIPTION
#     This script is called as-is and included with every patch update for historical
#     and compatibility reasons. As of version 3.2.0 this patch is optional. It reduces
#     the CPU usage on kernels with timer frequencies lower than 1000 Hz.
#
# EXIT STATUS
#     0      : The patch was applied successfully or is not needed for this game version.
#     other  : Patch failure. See stdout or stderr output for details.


# Templates for the next patch testing phase
echo "          This is an OPTIONAL patch to reduce CPU usage by disabling mhypbase.dll."
echo "[WARNING]       !! UNTESTED PATCH. CHECK FOR BANS USING A TRASH ACCOUNT !!"
echo ""
echo "If you would like to test this patch, modify this script and remove the line below this one."
#exit 0

#echo "[WARNING] This patch reduces the CPU load but might cause a game crash"
#echo "          due to server-sent code upon login. To revert the changes of,"
#echo "          this script, revert the patches and reapply the main one only."


DIR=$(dirname "${BASH_SOURCE[0]}")
FILE="mhypbase.dll"


# =========== DO NOT REMOVE START ===========
if [[ -e "$DIR/$FILE" ]]; then
	# There is a good reason for this check. Do not pollute the game directory.
	echo "[ERROR] Invalid patch download directory. Please move all"
	echo "        patch files outside the game directory prior executing."
	echo " -> See README.md for proper installation instructions" && exit 1
fi
# ===========  DO NOT REMOVE END  ===========

if [ ! -e "$FILE" ]; then
	echo "==> Already applied."
	exit 0
fi

# ===========================================================
echo ""
echo "[WARNING] Hereby you are violating the game's Terms of Service!"
echo "          Do you accept the risk and possible consequences?"
echo "          Use Ctrl+C to abort this script if you are not sure."
read -p "Accept? [y/N] " choice

if [[ ! "$choice" == [JjSsYy]* ]]; then
	exit 1
fi

# Disable by renaming
echo "--- Disabling mhypbase"
mv -f "mhypbase.dll" "mhypbase.dll.bak"

# Done!
echo "==> Patch applied! Enjoy the game."
exit 0
